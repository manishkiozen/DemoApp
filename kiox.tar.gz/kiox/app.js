/**
* start node application
**/ 

var app = require('./lib/config');
app.init();